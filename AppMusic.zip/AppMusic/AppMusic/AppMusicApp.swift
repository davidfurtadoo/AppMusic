//
//  AppMusicApp.swift
//  AppMusic
//
//  Created by David Furtado on 26/01/23.
//

import SwiftUI

@main
struct AppMusicApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
