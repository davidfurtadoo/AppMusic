//
//  Account.swift
//  AppMusic
//
//  Created by David Furtado on 23/02/23.
//

import SwiftUI

struct Account: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Account_Previews: PreviewProvider {
    static var previews: some View {
        Account()
    }
}
