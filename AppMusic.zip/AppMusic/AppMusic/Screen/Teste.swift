//
//  Teste.swift
//  AppMusic
//
//  Created by David Furtado on 13/03/23.
//

import SwiftUI

struct Teste: View {
    var body: some View {
        DemoList()
    }
}


struct Teste_Previews: PreviewProvider {
    static var previews: some View {
        Teste()
    }
}
