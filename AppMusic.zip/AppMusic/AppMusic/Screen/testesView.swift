//
//  testesView.swift
//  AppMusic
//
//  Created by David Furtado on 06/03/23.
//

import SwiftUI

struct testesView: View {
    var body: some View {
        
    }
}

struct testesView_Previews: PreviewProvider {
    static var previews: some View {
        testesView()
    }
}
